/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.enums;

public enum MoveState {
    NOTEMOVAIMIERGDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA;
    
    public static MoveState state;

    private MoveState() {
    }
}

