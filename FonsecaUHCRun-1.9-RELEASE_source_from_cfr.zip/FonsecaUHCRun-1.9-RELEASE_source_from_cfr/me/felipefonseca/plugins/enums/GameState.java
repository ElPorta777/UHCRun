/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.enums;

public enum GameState {
    PREPARING,
    LOBBY,
    TELEPORTING,
    PVE,
    PVP,
    DEATHMATCH,
    ENDING;
    
    public static GameState state;

    private GameState() {
    }
}

