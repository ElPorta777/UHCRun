/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Server
 *  org.bukkit.entity.Player
 *  org.bukkit.scheduler.BukkitRunnable
 */
package me.felipefonseca.plugins.task;

import java.util.Collection;
import java.util.function.Consumer;
import java.util.stream.Stream;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.manager.PlayerManager;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class WinnerTask
extends BukkitRunnable {
    private final Main plugin;
    private int count;

    public WinnerTask(Main main) {
        this.plugin = main;
        this.count = 10;
    }

    public void run() {
        if (this.count == 0) {
            this.plugin.getServer().getOnlinePlayers().stream().forEach(player -> {
                this.plugin.getPlayerManager().sendToServer(player);
            }
            );
            this.plugin.getServer().shutdown();
            this.cancel();
        }
        --this.count;
    }
}

