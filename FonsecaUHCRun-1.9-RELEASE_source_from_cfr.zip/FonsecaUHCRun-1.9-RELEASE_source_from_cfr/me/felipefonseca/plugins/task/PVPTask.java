/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 */
package me.felipefonseca.plugins.task;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.enums.GameState;
import me.felipefonseca.plugins.manager.GameManager;
import me.felipefonseca.plugins.manager.config.ConfigurationManager;
import me.felipefonseca.plugins.utils.Messages;
import me.felipefonseca.plugins.utils.Tools;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class PVPTask
extends BukkitRunnable {
    private int totalTime;
    private final Main plugin;

    public PVPTask(Main main) {
        this.plugin = main;
        this.totalTime = 600;
    }

    public void run() {
        this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
            this.plugin.getMessageController().sendActionBar(player, this.plugin.getConfigurationManager().getText("titles.timer").replace("%time%", Tools.transform(this.totalTime)));
        }
        );
        if (this.totalTime % 300 == 0 && this.totalTime > 0) {
            this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
                this.plugin.getMessageController().sendTitle(player, "", this.plugin.getConfigurationManager().getText("titles.toDM").replace("%time%", "" + this.totalTime / 60), 0, 10, 0);
            }
            );
            this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("titles.toDM").replace("%time%", "" + this.totalTime / 60));
        } else if (this.totalTime > 0 && this.totalTime <= 5) {
            String string = this.totalTime == 1 ? "" : "s";
            this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
                this.plugin.getMessageController().sendTitle(player, "", this.plugin.getConfigurationManager().getText("titles.toDMSeconds").replace("%s%", string).replace("%time%", "" + this.totalTime), 0, 10, 0);
            }
            );
            this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("titles.toDMSeconds").replace("%time%", "" + this.totalTime).replace("%s%", string));
        } else if (this.totalTime == 0) {
            this.plugin.getGameManager().getPlayersInGame().stream().map(player -> {
                this.plugin.getMessageController().sendTitle(player, "", this.plugin.getConfigurationManager().getText("titles.deathmatch"), 0, 10, 0);
                return player;
            }
            ).forEach(player -> {
                player.playSound(player.getLocation(), Sound.AMBIENCE_THUNDER, 1.0f, 1.0f);
                player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, Integer.MAX_VALUE, 1));
            }
            );
            GameState.state = GameState.DEATHMATCH;
            this.cancel();
        }
        --this.totalTime;
    }
}

