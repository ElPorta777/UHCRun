/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Effect
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Server
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitScheduler
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.scoreboard.Scoreboard
 *  org.bukkit.scoreboard.ScoreboardManager
 */
package me.felipefonseca.plugins.task;

import java.util.HashMap;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.enums.GameState;
import me.felipefonseca.plugins.enums.MoveState;
import me.felipefonseca.plugins.manager.ArenaManager;
import me.felipefonseca.plugins.manager.GameManager;
import me.felipefonseca.plugins.manager.PlayerManager;
import me.felipefonseca.plugins.manager.config.ConfigurationManager;
import me.felipefonseca.plugins.task.PVETask;
import me.felipefonseca.plugins.utils.GroundUtil;
import me.felipefonseca.plugins.utils.Messages;
import org.bukkit.Effect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

public class TeleportTask
extends BukkitRunnable {
    private final Main plugin;
    private int count;

    public TeleportTask(Main main) {
        this.plugin = main;
        this.count = 15;
    }

    public void run() {
        this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
            player.setLevel(this.count);
        }
        );
        if (this.count == 15) {
            this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
                this.plugin.getMessageController().sendTitle(player, this.plugin.getConfigurationManager().getText("titles.teleporting"), this.plugin.getConfigurationManager().getText("titles.teleporting2"), 20, 20, 20);
                GroundUtil.removeGround(player.getLocation());
                this.plugin.getArenaManager().enviarJugadores(player);
            }
            );
        } else if (this.count > 0 && this.count <= 5) {
            this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("titles.released").replace("%time%", "" + this.count));
        } else if (this.count == 1) {
            MoveState.state = MoveState.NOTEMOVAIMIERGDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA;
        } else if (this.count == 0) {
            this.plugin.getArenaManager().removeUsedSpawnOnTeleport();
            for (Player player2 : this.plugin.getGameManager().getPlayersInGame()) {
                GroundUtil.removeGround(player2.getLocation());
                MoveState.state = null;
                player2.playSound(player2.getLocation(), Sound.EXPLODE, 1.0f, 1.0f);
                player2.playEffect(player2.getLocation(), Effect.EXPLOSION_LARGE, 10);
                this.plugin.getPlayerManager().setCleanPlayer(player2, GameMode.SURVIVAL);
                player2.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 200, 5));
                player2.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 5));
                player2.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 24000, 1, true, false));
                player2.getInventory().addItem(new ItemStack[]{new ItemStack(Material.COOKED_BEEF, 5)});
                player2.setFoodLevel(20);
                player2.setScoreboard(this.plugin.getServer().getScoreboardManager().getNewScoreboard());
                this.plugin.getPlayerManager().setScoreboard(player2);
                this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                    this.plugin.getMessageController().sendTitle(player2, this.plugin.getConfigurationManager().getText("titles.gl"), "", 0, 5, 0);
                }
                );
            }
            new PVETask(this.plugin).runTaskTimer((Plugin)this.plugin, 20, 20);
            GameState.state = GameState.PVE;
            this.cancel();
        }
        --this.count;
    }
}

