/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package me.felipefonseca.plugins.task;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.enums.GameState;
import me.felipefonseca.plugins.enums.MoveState;
import me.felipefonseca.plugins.manager.ArenaManager;
import me.felipefonseca.plugins.manager.GameManager;
import me.felipefonseca.plugins.manager.config.ConfigurationManager;
import me.felipefonseca.plugins.task.TeleportTask;
import me.felipefonseca.plugins.utils.GroundUtil;
import me.felipefonseca.plugins.utils.Messages;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class LobbyTask
extends BukkitRunnable {
    private final Main plugin;
    private int count;

    public LobbyTask(Main main) {
        this.plugin = main;
        this.count = 30;
    }

    public void run() {
        this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
            player.setLevel(this.count);
        }
        );
        if (this.count == 30) {
            this.plugin.getGameManager().getPlayersInGame().stream().map(player -> {
                this.plugin.getMessageController().sendTitle(player, this.plugin.getConfigurationManager().getText("titles.title1"), this.plugin.getConfigurationManager().getText("titles.title2"), 20, 20, 20);
                return player;
            }
            ).forEach(player -> {
                player.playSound(player.getLocation(), Sound.ENDERDRAGON_GROWL, 1.0f, 1.0f);
            }
            );
            this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("titles.broadcast1"));
        } else if (this.count == 10) {
            this.plugin.getGameManager().getPlayersInGame().stream().map(player -> {
                this.plugin.getMessageController().sendTitle(player, this.plugin.getConfigurationManager().getText("titles.seconds").replace("%time%", "" + this.count), this.plugin.getConfigurationManager().getText("titles.toStart"), 20, 20, 20);
                return player;
            }
            ).forEach(player -> {
                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
            }
            );
        } else if (this.count > 0 && this.count <= 5) {
            this.plugin.getGameManager().getPlayersInGame().stream().map(player -> {
                this.plugin.getMessageController().sendTitle(player, "&c&l" + this.count, "", 40, 40, 40);
                return player;
            }
            ).forEach(player -> {
                player.playSound(player.getLocation(), Sound.CLICK, 1.0f, 1.0f);
            }
            );
        } else if (this.count == 1) {
            MoveState.state = MoveState.NOTEMOVAIMIERGDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA;
        } else if (this.count == 0) {
            this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
                GroundUtil.removeGround(player.getLocation());
            }
            );
            this.plugin.getArenaManager().removeSpawns();
            new TeleportTask(this.plugin).runTaskTimer((Plugin)this.plugin, 20, 20);
            GameState.state = GameState.TELEPORTING;
            MoveState.state = null;
            this.cancel();
        }
        --this.count;
    }
}

