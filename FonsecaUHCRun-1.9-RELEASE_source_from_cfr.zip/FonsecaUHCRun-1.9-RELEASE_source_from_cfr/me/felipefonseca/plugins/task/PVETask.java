/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Server
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.WorldBorder
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package me.felipefonseca.plugins.task;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.enums.GameState;
import me.felipefonseca.plugins.manager.ArenaManager;
import me.felipefonseca.plugins.manager.GameManager;
import me.felipefonseca.plugins.manager.config.ConfigurationManager;
import me.felipefonseca.plugins.task.PVPTask;
import me.felipefonseca.plugins.utils.Messages;
import me.felipefonseca.plugins.utils.Tools;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class PVETask
extends BukkitRunnable {
    private int totalTime;
    private final Main plugin;

    public PVETask(Main main) {
        this.plugin = main;
        this.totalTime = 1200;
    }

    public void run() {
        this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
            this.plugin.getMessageController().sendActionBar(player, this.plugin.getConfigurationManager().getText("titles.timer").replace("%time%", Tools.transform(this.totalTime)));
        }
        );
        if (this.totalTime % 300 == 0 && this.totalTime > 0) {
            this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
                this.plugin.getMessageController().sendTitle(player, "", this.plugin.getConfigurationManager().getText("titles.toPVP").replace("%time%", "" + this.totalTime / 60), 0, 10, 0);
            }
            );
            this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("titles.toPVP").replace("%time%", "" + this.totalTime / 60));
        } else if (this.totalTime > 0 && this.totalTime <= 5) {
            String string = this.totalTime == 1 ? "" : "s";
            this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
                this.plugin.getMessageController().sendTitle(player, "", this.plugin.getConfigurationManager().getText("titles.toPVPSeconds").replace("%time%", "" + this.totalTime).replace("%s%", string), 0, 10, 0);
            }
            );
            this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("titles.toPVPSeconds").replace("%s%", string).replace("%time%", "" + this.totalTime));
        } else if (this.totalTime == 0) {
            this.plugin.getGameManager().getPlayersInGame().stream().map(player -> {
                this.plugin.getMessageController().sendTitle(player, "", this.plugin.getConfigurationManager().getText("titles.pvp_enabled"), 0, 10, 0);
                return player;
            }
            ).forEach(player -> {
                player.playSound(player.getLocation(), Sound.WOLF_GROWL, 1.0f, 1.0f);
                this.plugin.getArenaManager().removePVE(player);
                player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 200, 5));
            }
            );
            GameState.state = GameState.PVP;
            this.plugin.getServer().getWorld("world").getWorldBorder().setSize(600.0);
            this.plugin.getServer().getWorld("world").getWorldBorder().setSize(this.plugin.getArenaManager().getDeathMatchSize(), 12000);
            this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("titles.pvp_enabled"));
            this.plugin.getGameManager().removeOfflinePlayers();
            new PVPTask(this.plugin).runTaskTimer((Plugin)this.plugin, 20, 20);
            this.cancel();
        }
        --this.totalTime;
    }
}

