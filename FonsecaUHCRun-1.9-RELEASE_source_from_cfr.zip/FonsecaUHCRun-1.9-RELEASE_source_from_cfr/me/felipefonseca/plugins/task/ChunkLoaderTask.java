/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Chunk
 *  org.bukkit.scheduler.BukkitRunnable
 */
package me.felipefonseca.plugins.task;

import java.util.logging.Level;
import java.util.logging.Logger;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.enums.GameState;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.scheduler.BukkitRunnable;

public class ChunkLoaderTask
extends BukkitRunnable {
    private final Main plugin;
    private double percent;
    private int ancientPercent;
    private double currentChunkLoad;
    private final double totalChunkToLoad;
    private int cx;
    private final int cz;

    public ChunkLoaderTask(Main main, int n) {
        this.plugin = main;
        this.percent = 0.0;
        this.ancientPercent = 0;
        this.cz = this.cx = n / 16 + 1;
        this.totalChunkToLoad = 2 * this.cx;
        this.currentChunkLoad = -1.0;
        this.cx = - this.cx;
    }

    public void run() {
        for (int i = - this.cz; i <= this.cz; ++i) {
            try {
                Chunk chunk = Bukkit.getWorld((String)"world").getChunkAt(this.cx, i);
                chunk.load(true);
                continue;
            }
            catch (Exception var2_3) {
                // empty catch block
            }
        }
        this.currentChunkLoad += 1.0;
        ++this.cx;
        this.percent = this.currentChunkLoad / this.totalChunkToLoad * 100.0;
        if (this.ancientPercent < (int)this.percent) {
            this.plugin.getLogger().log(Level.INFO, "UHCRun: Loading Chunks... {0} %", (int)this.percent);
            this.ancientPercent = (int)this.percent;
        }
        if (this.percent >= 100.0) {
            this.plugin.getLogger().log(Level.INFO, "UHCRun: World ready, ready to use");
            GameState.state = GameState.LOBBY;
            this.cancel();
        }
    }
}

