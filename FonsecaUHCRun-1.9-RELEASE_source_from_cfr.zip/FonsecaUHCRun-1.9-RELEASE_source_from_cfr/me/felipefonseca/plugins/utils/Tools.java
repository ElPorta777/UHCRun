/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.v1_8_R3.ItemStack
 *  net.minecraft.server.v1_8_R3.NBTBase
 *  net.minecraft.server.v1_8_R3.NBTTagCompound
 *  net.minecraft.server.v1_8_R3.NBTTagList
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package me.felipefonseca.plugins.utils;

import net.minecraft.server.v1_8_R3.NBTBase;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.minecraft.server.v1_8_R3.NBTTagList;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class Tools {
    public static int getY(Player player) {
        double d = player.getLocation().getY();
        int n = (int)d;
        return n;
    }

    public static int getCentre(Player player) {
        Location location = new Location(Bukkit.getWorld((String)"world"), 0.0, 60.0, 0.0);
        int n = (int)Math.floor(player.getLocation().distance(location));
        return n;
    }

    public static ItemStack glow(ItemStack itemStack) {
        net.minecraft.server.v1_8_R3.ItemStack itemStack2 = CraftItemStack.asNMSCopy((ItemStack)itemStack);
        NBTTagCompound nBTTagCompound = null;
        if (!itemStack2.hasTag()) {
            nBTTagCompound = new NBTTagCompound();
            itemStack2.setTag(nBTTagCompound);
        }
        if (nBTTagCompound == null) {
            nBTTagCompound = itemStack2.getTag();
        }
        NBTTagList nBTTagList = new NBTTagList();
        nBTTagCompound.set("ench", (NBTBase)nBTTagList);
        itemStack2.setTag(nBTTagCompound);
        return CraftItemStack.asCraftMirror((net.minecraft.server.v1_8_R3.ItemStack)itemStack2);
    }

    public static String transform(double d) {
        boolean bl = false;
        if (d < 0.0) {
            bl = true;
            d *= -1.0;
        }
        int n = (int)d / 3600;
        int n2 = (int)(d - (double)(n * 3600)) / 60;
        int n3 = (int)d - n * 3600 - n2 * 60;
        String string = "" + n + "";
        String string2 = "" + n2 + "";
        String string3 = "" + n3 + "";
        while (string2.length() < 2) {
            string2 = "0" + string2;
        }
        while (string3.length() < 2) {
            string3 = "0" + string3;
        }
        return (bl ? "-" : "") + (n == 0 ? "" : new StringBuilder().append(string).append(":").toString()) + string2 + ":" + string3;
    }

    public static String locationToString(Location location) {
        return String.valueOf(new StringBuilder(String.valueOf(location.getWorld().getName())).append(":").append(location.getBlockX()).toString()) + ":" + String.valueOf(location.getBlockY()) + ":" + String.valueOf(location.getBlockZ());
    }

    public static Location stringToLoc(String string) {
        Location location = null;
        try {
            World world = Bukkit.getWorld((String)string.split(":")[0]);
            Double d = Double.parseDouble(string.split(":")[1]);
            Double d2 = Double.parseDouble(string.split(":")[2]);
            Double d3 = Double.parseDouble(string.split(":")[3]);
            location = new Location(world, d + 0.5, d2.doubleValue(), d3 + 0.5);
        }
        catch (Exception var2_3) {
            // empty catch block
        }
        return location;
    }
}

