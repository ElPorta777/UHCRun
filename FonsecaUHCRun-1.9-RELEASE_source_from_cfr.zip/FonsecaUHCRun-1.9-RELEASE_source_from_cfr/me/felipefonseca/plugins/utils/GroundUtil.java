/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.inventory.ItemStack
 */
package me.felipefonseca.plugins.utils;

import java.util.Random;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;

public class GroundUtil {
    private static final Random rand = new Random();

    public static void setBuildGround(Location location) {
        int n = rand.nextInt(15);
        switch (n) {
            case 1: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 2: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 3: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 4: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 5: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 6: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 8: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 9: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 10: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 11: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 12: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 13: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            case 14: {
                GroundUtil.buildGround(location, (byte)n);
                break;
            }
            default: {
                GroundUtil.buildGround(location, 0);
            }
        }
    }

    public static void removeGround(Location location) {
        int n = location.getBlockX();
        int n2 = location.getBlockY();
        int n3 = location.getBlockZ();
        location.getWorld().getBlockAt(n, n2 - 1, n3).setType(Material.AIR);
        location.getWorld().getBlockAt(n + 1, n2 - 1, n3).setType(Material.AIR);
        location.getWorld().getBlockAt(n, n2 - 1, n3 + 1).setType(Material.AIR);
        location.getWorld().getBlockAt(n + 1, n2 - 1, n3 + 1).setType(Material.AIR);
        location.getWorld().getBlockAt(n, n2 - 1, n3 - 1).setType(Material.AIR);
        location.getWorld().getBlockAt(n - 1, n2 - 1, n3).setType(Material.AIR);
        location.getWorld().getBlockAt(n - 1, n2 - 1, n3 - 1).setType(Material.AIR);
        location.getWorld().getBlockAt(n + 1, n2 - 1, n3 - 1).setType(Material.AIR);
        location.getWorld().getBlockAt(n - 1, n2 - 1, n3 + 1).setType(Material.AIR);
        location.getWorld().getBlockAt(n - 1, n2 - 1, n3 - 1).setType(Material.AIR);
    }

    private static void buildGround(Location location, byte by) {
        ItemStack itemStack = new ItemStack(Material.STAINED_GLASS);
        ItemStack itemStack2 = new ItemStack(Material.STAINED_CLAY);
        if (by == 333) {
            itemStack = new ItemStack(Material.GLASS);
            itemStack2 = new ItemStack(Material.STAINED_CLAY);
            by = 0;
        }
        int n = location.getBlockX();
        int n2 = location.getBlockY();
        int n3 = location.getBlockZ();
        location.getWorld().getBlockAt(n, n2 - 1, n3).setTypeIdAndData(itemStack2.getTypeId(), by, true);
        location.getWorld().getBlockAt(n + 1, n2 - 1, n3).setTypeIdAndData(itemStack.getTypeId(), by, true);
        location.getWorld().getBlockAt(n, n2 - 1, n3 + 1).setTypeIdAndData(itemStack.getTypeId(), by, true);
        location.getWorld().getBlockAt(n + 1, n2 - 1, n3 + 1).setTypeIdAndData(itemStack.getTypeId(), by, true);
        location.getWorld().getBlockAt(n, n2 - 1, n3 - 1).setTypeIdAndData(itemStack.getTypeId(), by, true);
        location.getWorld().getBlockAt(n - 1, n2 - 1, n3).setTypeIdAndData(itemStack.getTypeId(), by, true);
        location.getWorld().getBlockAt(n - 1, n2 - 1, n3 - 1).setTypeIdAndData(itemStack.getTypeId(), by, true);
        location.getWorld().getBlockAt(n + 1, n2 - 1, n3 - 1).setTypeIdAndData(itemStack.getTypeId(), by, true);
        location.getWorld().getBlockAt(n - 1, n2 - 1, n3 + 1).setTypeIdAndData(itemStack.getTypeId(), by, true);
        location.getWorld().getBlockAt(n - 1, n2 - 1, n3 - 1).setTypeIdAndData(itemStack.getTypeId(), by, true);
    }
}

