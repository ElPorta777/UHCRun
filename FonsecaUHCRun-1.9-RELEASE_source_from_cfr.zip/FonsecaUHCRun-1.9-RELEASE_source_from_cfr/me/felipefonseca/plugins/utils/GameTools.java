/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Effect
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Server
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.ExperienceOrb
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.LeavesDecayEvent
 *  org.bukkit.event.entity.EntityDeathEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.Recipe
 *  org.bukkit.inventory.ShapedRecipe
 *  org.bukkit.inventory.ShapelessRecipe
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 *  org.bukkit.scheduler.BukkitScheduler
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.Vector
 */
package me.felipefonseca.plugins.utils;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import me.felipefonseca.plugins.Main;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class GameTools {
    private static final Random rand = new Random();

    public static boolean recipeContainsMaterial(Recipe recipe, Material material) {
        List list = null;
        if (recipe instanceof ShapedRecipe) {
            list = ((ShapedRecipe)recipe).getIngredientMap().values();
        }
        if (recipe instanceof ShapelessRecipe) {
            list = ((ShapelessRecipe)recipe).getIngredientList();
        }
        if (list == null) {
            return false;
        }
        for (ItemStack itemStack : list) {
            if (!itemStack.getType().equals((Object)material)) continue;
            return true;
        }
        return false;
    }

    public static void onEntityDeath(EntityDeathEvent entityDeathEvent) {
        switch (entityDeathEvent.getEntityType()) {
            case COW: {
                GameTools.dropEntity(entityDeathEvent, Material.COOKED_BEEF, Material.LEATHER, 2, 3, 3);
                break;
            }
            case SHEEP: {
                GameTools.dropEntity(entityDeathEvent, Material.COOKED_MUTTON, Material.LEATHER, 3, 2, 2);
                break;
            }
            case HORSE: {
                GameTools.dropEntity(entityDeathEvent, Material.COOKED_MUTTON, Material.LEATHER, 1, 1, 1);
                break;
            }
            case CHICKEN: {
                GameTools.dropEntity(entityDeathEvent, Material.COOKED_CHICKEN, Material.ARROW, 3, 2, 2);
                GameTools.dropEntity(entityDeathEvent, Material.LEATHER, Material.LEATHER, 1, 1, 0);
                break;
            }
            case RABBIT: {
                GameTools.dropEntity(entityDeathEvent, Material.COOKED_RABBIT, Material.LEATHER, 2, 1, 1);
                break;
            }
            case PIG: {
                GameTools.dropEntity(entityDeathEvent, Material.GRILLED_PORK, Material.LEATHER, 3, 3, 3);
                break;
            }
            case ZOMBIE: {
                GameTools.dropEntity(entityDeathEvent, Material.COOKED_BEEF, Material.COOKED_BEEF, 1, 0, 1);
                break;
            }
            case WITCH: {
                Iterator iterator = entityDeathEvent.getDrops().iterator();
                while (iterator.hasNext()) {
                    ItemStack itemStack = (ItemStack)iterator.next();
                    if (itemStack.getType() != Material.GLOWSTONE_DUST) continue;
                    iterator.remove();
                }
                break;
            }
        }
    }

    public static void checkOre(BlockBreakEvent blockBreakEvent, Main main) {
        switch (blockBreakEvent.getBlock().getType()) {
            case DIAMOND_ORE: {
                GameTools.dropOre(blockBreakEvent, Material.DIAMOND, 6);
                break;
            }
            case GOLD_ORE: {
                GameTools.dropOre(blockBreakEvent, Material.GOLD_INGOT, 4);
                break;
            }
            case COAL_ORE: {
                GameTools.dropOre(blockBreakEvent, Material.TORCH, 8);
                break;
            }
            case IRON_ORE: {
                GameTools.dropOre(blockBreakEvent, Material.IRON_INGOT, 3);
                break;
            }
            case GRAVEL: {
                GameTools.dropOre(blockBreakEvent, Material.ARROW, 2);
                GameTools.dropOre(blockBreakEvent, Material.FLINT, 0);
                break;
            }
            case SAND: {
                GameTools.dropOre(blockBreakEvent, Material.GLASS, 1);
                break;
            }
            case STONE: {
                GameTools.normalDrop(blockBreakEvent, Material.COBBLESTONE, 1);
                break;
            }
            case SUGAR_CANE_BLOCK: {
                int n = rand.nextInt(100);
                if (n >= 50) {
                    GameTools.normalDrop(blockBreakEvent, Material.SUGAR_CANE, 5);
                    break;
                }
                GameTools.normalDrop(blockBreakEvent, Material.SUGAR_CANE, 3);
                break;
            }
            case LOG: 
            case LOG_2: {
                GameTools.breakBlock(blockBreakEvent, main);
            }
        }
    }

    private static void dropEntity(EntityDeathEvent entityDeathEvent, Material material, Material material2, int n, int n2, int n3) {
        entityDeathEvent.getDrops().clear();
        entityDeathEvent.getEntity().getLocation().getWorld().dropItem(entityDeathEvent.getEntity().getLocation().add(0.5, 0.5, 0.5), new ItemStack(material, n)).setVelocity(new Vector(0, 0, 0));
        entityDeathEvent.getEntity().getLocation().getWorld().dropItem(entityDeathEvent.getEntity().getLocation().add(0.5, 0.5, 0.5), new ItemStack(material2, n2)).setVelocity(new Vector(0, 0, 0));
        GameTools.dropXP(entityDeathEvent.getEntity().getLocation(), n3);
    }

    private static void normalDrop(BlockBreakEvent blockBreakEvent, Material material, int n) {
        blockBreakEvent.setCancelled(true);
        blockBreakEvent.getBlock().setType(Material.AIR);
        blockBreakEvent.getBlock().getWorld().dropItem(blockBreakEvent.getBlock().getLocation().add(0.5, 0.5, 0.5), new ItemStack(material, n)).setVelocity(new Vector(0, 0, 0));
    }

    private static void dropOre(BlockBreakEvent blockBreakEvent, Material material, int n) {
        blockBreakEvent.setCancelled(true);
        blockBreakEvent.getBlock().setType(Material.AIR);
        blockBreakEvent.getBlock().getWorld().dropItem(blockBreakEvent.getBlock().getLocation().add(0.5, 0.5, 0.5), new ItemStack(material, 2)).setVelocity(new Vector(0, 0, 0));
        GameTools.dropXP(blockBreakEvent.getBlock().getLocation(), n);
    }

    private static void dropXP(Location location, int n) {
        ExperienceOrb experienceOrb = (ExperienceOrb)location.getWorld().spawn(location.getBlock().getLocation().add(0.5, 0.5, 0.5), (Class)ExperienceOrb.class);
        experienceOrb.setExperience(n);
    }

    public static void breakBlock(BlockBreakEvent blockBreakEvent, Main main) {
        Location location = blockBreakEvent.getBlock().getLocation();
        World world = location.getWorld();
        int n = location.getBlockX();
        int n2 = location.getBlockY();
        int n3 = location.getBlockZ();
        int n4 = 4;
        int n5 = 5;
        if (!GameTools.validChunk(world, n - 5, n2 - 5, n3 - 5, n + 5, n2 + 5, n3 + 5)) {
            return;
        }
        main.getServer().getScheduler().runTask((Plugin)main, () -> {
            for (int i = -4; i <= 4; ++i) {
                for (int j = -4; j <= 4; ++j) {
                    for (int k = -4; k <= 4; ++k) {
                        if (world.getBlockTypeIdAt(n + i, n2 + j, n3 + k) != Material.LEAVES.getId() && world.getBlockTypeIdAt(n + i, n2 + j, n3 + k) != Material.LEAVES_2.getId()) continue;
                        GameTools.breakLeaf(main, world, n + i, n2 + j, n3 + k);
                    }
                }
            }
        }
        );
        GameTools.breakTree(blockBreakEvent.getBlock(), blockBreakEvent.getPlayer(), main);
    }

    public static void breakTree(Block block, Player player, Main main) {
        if (block.getType() != Material.LOG && block.getType() != Material.LOG_2) {
            return;
        }
        block.breakNaturally();
        BlockBreakEvent blockBreakEvent = null;
        for (BlockFace blockFace : BlockFace.values()) {
            blockBreakEvent = new BlockBreakEvent(block.getRelative(blockFace), player);
            main.getServer().getPluginManager().callEvent((Event)blockBreakEvent);
            blockBreakEvent = new BlockBreakEvent(block.getRelative(blockFace).getRelative(BlockFace.UP), player);
            main.getServer().getPluginManager().callEvent((Event)blockBreakEvent);
        }
    }

    public static void breakLeaf(Main main, World world, int n, int n2, int n3) {
        Block block = world.getBlockAt(n, n2, n3);
        int n4 = 4;
        int n5 = 32;
        int[] arrn = new int[n5 * n5 * n5];
        int n6 = n4 + 1;
        int n7 = n5 * n5;
        int n8 = n5 / 2;
        if (GameTools.validChunk(world, n - n6, n2 - n6, n3 - n6, n + n6, n2 + n6, n3 + n6)) {
            int n9;
            int n10;
            int n11;
            int n12;
            for (n12 = - n4; n12 <= n4; ++n12) {
                for (n11 = - n4; n11 <= n4; ++n11) {
                    for (n9 = - n4; n9 <= n4; ++n9) {
                        n10 = world.getBlockTypeIdAt(n + n12, n2 + n11, n3 + n9);
                        arrn[(n12 + n8) * n7 + (n11 + n8) * n5 + n9 + n8] = n10 == Material.LOG.getId() || n10 == Material.LOG_2.getId() ? 0 : (n10 == Material.LEAVES.getId() || n10 == Material.LEAVES_2.getId() ? -2 : -1);
                    }
                }
            }
            for (n12 = 1; n12 <= 4; ++n12) {
                for (n11 = - n4; n11 <= n4; ++n11) {
                    for (n9 = - n4; n9 <= n4; ++n9) {
                        for (n10 = - n4; n10 <= n4; ++n10) {
                            if (arrn[(n11 + n8) * n7 + (n9 + n8) * n5 + n10 + n8] != n12 - 1) continue;
                            if (arrn[(n11 + n8 - 1) * n7 + (n9 + n8) * n5 + n10 + n8] == -2) {
                                arrn[(n11 + n8 - 1) * n7 + (n9 + n8) * n5 + n10 + n8] = n12;
                            }
                            if (arrn[(n11 + n8 + 1) * n7 + (n9 + n8) * n5 + n10 + n8] == -2) {
                                arrn[(n11 + n8 + 1) * n7 + (n9 + n8) * n5 + n10 + n8] = n12;
                            }
                            if (arrn[(n11 + n8) * n7 + (n9 + n8 - 1) * n5 + n10 + n8] == -2) {
                                arrn[(n11 + n8) * n7 + (n9 + n8 - 1) * n5 + n10 + n8] = n12;
                            }
                            if (arrn[(n11 + n8) * n7 + (n9 + n8 + 1) * n5 + n10 + n8] == -2) {
                                arrn[(n11 + n8) * n7 + (n9 + n8 + 1) * n5 + n10 + n8] = n12;
                            }
                            if (arrn[(n11 + n8) * n7 + (n9 + n8) * n5 + (n10 + n8 - 1)] == -2) {
                                arrn[(n11 + n8) * n7 + (n9 + n8) * n5 + (n10 + n8 - 1)] = n12;
                            }
                            if (arrn[(n11 + n8) * n7 + (n9 + n8) * n5 + n10 + n8 + 1] != -2) continue;
                            arrn[(n11 + n8) * n7 + (n9 + n8) * n5 + n10 + n8 + 1] = n12;
                        }
                    }
                }
            }
        }
        if (arrn[n8 * n7 + n8 * n5 + n8] < 0) {
            Location location = block.getLocation();
            LeavesDecayEvent leavesDecayEvent = new LeavesDecayEvent(block);
            main.getServer().getPluginManager().callEvent((Event)leavesDecayEvent);
            main.getServer().getWorld("world").playEffect(location, Effect.STEP_SOUND, Material.LEAVES.getId(), 15);
        }
    }

    public static boolean validChunk(World world, int n, int n2, int n3, int n4, int n5, int n6) {
        if (n5 >= 0 && n2 < world.getMaxHeight()) {
            n3 >>= 4;
            n6 >>= 4;
            for (int i = n >>= 4; i <= (n4 >>= 4); ++i) {
                for (int j = n3; j <= n6; ++j) {
                    if (world.isChunkLoaded(i, j)) continue;
                    return false;
                }
            }
            return true;
        }
        return false;
    }

}

