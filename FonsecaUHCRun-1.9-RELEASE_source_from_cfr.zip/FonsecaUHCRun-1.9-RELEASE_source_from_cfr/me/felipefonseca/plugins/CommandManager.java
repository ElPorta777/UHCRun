/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.PluginCommand
 *  org.bukkit.entity.Player
 */
package me.felipefonseca.plugins;

import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.manager.GameManager;
import me.felipefonseca.plugins.utils.Messages;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;

public class CommandManager
implements CommandExecutor {
    private final Main plugin;

    public CommandManager(Main main) {
        this.plugin = main;
    }

    public void init() {
        this.plugin.getCommand("game").setExecutor((CommandExecutor)this);
    }

    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] arrstring) {
        Player player = null;
        if (commandSender instanceof Player) {
            player = (Player)commandSender;
        }
        if (command.getName().equalsIgnoreCase("game") && player != null) {
            if (player.hasPermission("UHCRun.Admin")) {
                if (arrstring.length < 1) {
                    this.plugin.getMessageController().sendMessage(player, "&e/game start/forcestart");
                } else {
                    switch (arrstring[0].toLowerCase()) {
                        case "start": {
                            this.plugin.getGameManager().checkStart();
                            break;
                        }
                        case "forcestart": {
                            this.plugin.getGameManager().forceStart();
                            break;
                        }
                        default: {
                            this.plugin.getMessageController().sendMessage(player, "&e/game start/forcestart");
                            break;
                        }
                    }
                }
            } else {
                this.plugin.getMessageController().sendMessage(player, "&7Ups... jijijaja");
            }
        }
        return false;
    }
}

