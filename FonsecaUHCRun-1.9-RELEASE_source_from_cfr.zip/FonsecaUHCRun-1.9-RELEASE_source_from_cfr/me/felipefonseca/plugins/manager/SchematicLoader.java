/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import me.felipefonseca.plugins.manager.NBT_Tag;
import me.felipefonseca.plugins.manager.NBT_Tag_Byte_Array;
import me.felipefonseca.plugins.manager.NBT_Tag_Compound;
import me.felipefonseca.plugins.manager.NBT_Tag_Short;

public class SchematicLoader {
    private byte[] blocks;
    private byte[] metadata;
    private short width;
    private short height;
    private short length;

    public void loadSchematic(DataInput dataInput) {
        NBT_Tag nBT_Tag = NBT_Tag.readTag(dataInput);
        NBT_Tag_Compound nBT_Tag_Compound = (NBT_Tag_Compound)nBT_Tag;
        this.width = ((NBT_Tag_Short)nBT_Tag_Compound.payload.get((Object)"Width")).payload;
        this.height = ((NBT_Tag_Short)nBT_Tag_Compound.payload.get((Object)"Height")).payload;
        this.length = ((NBT_Tag_Short)nBT_Tag_Compound.payload.get((Object)"Length")).payload;
        this.blocks = ((NBT_Tag_Byte_Array)nBT_Tag_Compound.payload.get((Object)"Blocks")).payload;
        this.metadata = ((NBT_Tag_Byte_Array)nBT_Tag_Compound.payload.get((Object)"Data")).payload;
    }

    public void writeUncompressedSchematic(DataOutput dataOutput) {
        NBT_Tag_Compound nBT_Tag_Compound = new NBT_Tag_Compound("Schematic");
        nBT_Tag_Compound.payload.put("Width", new NBT_Tag_Short("Width", this.width));
        nBT_Tag_Compound.payload.put("Height", new NBT_Tag_Short("Height", this.height));
        nBT_Tag_Compound.payload.put("Length", new NBT_Tag_Short("Length", this.length));
        nBT_Tag_Compound.payload.put("Blocks", new NBT_Tag_Byte_Array("Blocks", this.blocks));
        nBT_Tag_Compound.payload.put("Data", new NBT_Tag_Byte_Array("Data", this.metadata));
        nBT_Tag_Compound.writeTag(dataOutput);
    }

    public void writeUncompressedSchematic(File file) {
        DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(file));
        Throwable throwable = null;
        try {
            this.writeUncompressedSchematic(dataOutputStream);
        }
        catch (Throwable var4_5) {
            throwable = var4_5;
            throw var4_5;
        }
        finally {
            if (dataOutputStream != null) {
                if (throwable != null) {
                    try {
                        dataOutputStream.close();
                    }
                    catch (Throwable var4_4) {
                        throwable.addSuppressed(var4_4);
                    }
                } else {
                    dataOutputStream.close();
                }
            }
        }
    }

    public void writeGzipedSchematic(File file) {
        DataOutputStream dataOutputStream = new DataOutputStream(new GZIPOutputStream(new FileOutputStream(file)));
        Throwable throwable = null;
        try {
            this.writeUncompressedSchematic(dataOutputStream);
        }
        catch (Throwable var4_5) {
            throwable = var4_5;
            throw var4_5;
        }
        finally {
            if (dataOutputStream != null) {
                if (throwable != null) {
                    try {
                        dataOutputStream.close();
                    }
                    catch (Throwable var4_4) {
                        throwable.addSuppressed(var4_4);
                    }
                } else {
                    dataOutputStream.close();
                }
            }
        }
    }

    public void loadGzipedSchematic(InputStream inputStream) {
        DataInputStream dataInputStream = new DataInputStream(new GZIPInputStream(inputStream));
        Throwable throwable = null;
        try {
            this.loadSchematic(dataInputStream);
        }
        catch (Throwable var4_5) {
            throwable = var4_5;
            throw var4_5;
        }
        finally {
            if (dataInputStream != null) {
                if (throwable != null) {
                    try {
                        dataInputStream.close();
                    }
                    catch (Throwable var4_4) {
                        throwable.addSuppressed(var4_4);
                    }
                } else {
                    dataInputStream.close();
                }
            }
        }
    }

    public void loadUncompressedSchematic(InputStream inputStream) {
        DataInputStream dataInputStream = new DataInputStream(inputStream);
        Throwable throwable = null;
        try {
            this.loadSchematic(dataInputStream);
        }
        catch (Throwable var4_5) {
            throwable = var4_5;
            throw var4_5;
        }
        finally {
            if (dataInputStream != null) {
                if (throwable != null) {
                    try {
                        dataInputStream.close();
                    }
                    catch (Throwable var4_4) {
                        throwable.addSuppressed(var4_4);
                    }
                } else {
                    dataInputStream.close();
                }
            }
        }
    }

    private int getBlockOffset(int n, int n2, int n3) {
        return n2 * this.width * this.length + n3 * this.width + n;
    }

    public byte getBlockIdAt(int n, int n2, int n3) {
        int n4 = this.getBlockOffset(n, n2, n3);
        if (n4 < this.blocks.length && n4 >= 0) {
            return this.blocks[n4];
        }
        return -1;
    }

    public void setBlockIdAt(int n, int n2, int n3, byte by) {
        int n4 = this.getBlockOffset(n, n2, n3);
        if (n4 < this.blocks.length && n4 >= 0) {
            this.blocks[n4] = by;
        }
    }

    public byte getMetadataAt(int n, int n2, int n3) {
        int n4 = this.getBlockOffset(n, n2, n3);
        if (n4 < this.metadata.length && n4 >= 0) {
            return this.metadata[n4];
        }
        return 0;
    }

    public void setMetadataIdAt(int n, int n2, int n3, byte by) {
        int n4 = this.getBlockOffset(n, n2, n3);
        if (n4 < this.metadata.length && n4 >= 0) {
            this.metadata[n4] = by;
        }
    }

    public short getWidth() {
        return this.width;
    }

    public void setWidth(short s) {
        this.width = s;
    }

    public short getHeight() {
        return this.height;
    }

    public void setHeight(short s) {
        this.height = s;
    }

    public short getLength() {
        return this.length;
    }

    public void setLength(short s) {
        this.length = s;
    }

    public byte[] getBlocks() {
        return this.blocks;
    }

    public void setBlocks(byte[] arrby) {
        this.blocks = arrby;
    }

    public byte[] getMetadata() {
        return this.metadata;
    }

    public void setMetadata(byte[] arrby) {
        this.metadata = arrby;
    }
}

