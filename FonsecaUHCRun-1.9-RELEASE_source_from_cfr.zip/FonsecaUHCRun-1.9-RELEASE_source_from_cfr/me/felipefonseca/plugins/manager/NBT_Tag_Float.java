/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import me.felipefonseca.plugins.manager.NBT_Tag;

class NBT_Tag_Float
extends NBT_Tag {
    public float payload;

    public NBT_Tag_Float(String string) {
        super(5, string);
    }

    public NBT_Tag_Float(String string, float f) {
        super(8, string);
        this.payload = f;
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        this.payload = dataInput.readFloat();
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
        dataOutput.writeUTF(this.name);
        this.writePayload(dataOutput);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
        dataOutput.writeFloat(this.payload);
    }
}

