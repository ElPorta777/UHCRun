/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import me.felipefonseca.plugins.manager.NBT_Tag;

class NBT_Tag_Byte_Array
extends NBT_Tag {
    public int size;
    public byte[] payload;

    public NBT_Tag_Byte_Array(String string) {
        super(7, string);
    }

    public NBT_Tag_Byte_Array(String string, byte[] arrby) {
        super(8, string);
        this.payload = arrby;
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        int n;
        this.size = n = dataInput.readInt();
        this.payload = new byte[n];
        dataInput.readFully(this.payload);
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
        dataOutput.writeUTF(this.name);
        dataOutput.writeInt(this.size);
        this.writePayload(dataOutput);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
        for (byte by : this.payload) {
            dataOutput.writeByte(by);
        }
    }
}

