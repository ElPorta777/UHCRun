/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Chunk
 *  org.bukkit.Difficulty
 *  org.bukkit.Location
 *  org.bukkit.Server
 *  org.bukkit.World
 *  org.bukkit.WorldBorder
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package me.felipefonseca.plugins.manager;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.enums.GameState;
import me.felipefonseca.plugins.manager.config.ConfigurationManager;
import me.felipefonseca.plugins.manager.world.WorldManager;
import me.felipefonseca.plugins.task.ChunkLoaderTask;
import me.felipefonseca.plugins.utils.GroundUtil;
import me.felipefonseca.plugins.utils.Tools;
import org.bukkit.Chunk;
import org.bukkit.Difficulty;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class ArenaManager {
    private final Main plugin;
    private final double bordeSize;
    private final double deathMatchSize;
    private int minPlayers;
    private final int maxPlayers;
    private String netherSchematicName;
    private final List<Location> lobbySpawns;
    private final List<Location> lobbySpawnsUsed;
    private final List<Location> usedSpawnsToTeleport;
    private final Random rand;

    public ArenaManager(Main main) {
        this.plugin = main;
        this.rand = new Random();
        this.lobbySpawns = new ArrayList<Location>();
        this.lobbySpawnsUsed = new ArrayList<Location>();
        this.usedSpawnsToTeleport = new ArrayList<Location>();
        this.bordeSize = 1500.0;
        this.deathMatchSize = 50.0;
        this.maxPlayers = 40;
    }

    public void loadInfo() {
        this.netherSchematicName = this.plugin.getConfig().getString("netherSchematicName");
    }

    public void prepareArenaManager() {
        this.minPlayers = this.plugin.getConfig().getInt("minplayers");
        if (!this.plugin.getConfigurationManager().isCustomMap()) {
            this.plugin.getWorldManager().deleteWorld("world", true);
            this.plugin.getWorldManager().generateBiome();
        }
        new BukkitRunnable(){

            public void run() {
                if (ArenaManager.this.plugin.getWorldManager().loadWorld("world")) {
                    ArenaManager.this.plugin.getLogger().log(Level.INFO, "UHCRun: Preparting ARENA-MANAGER");
                    ArenaManager.this.loadSpawn();
                    if (ArenaManager.this.plugin.getConfigurationManager().isCustomMap()) {
                        ArenaManager.this.plugin.getLogger().log(Level.INFO, "UHCRun: Custom Map is enabled.");
                    } else {
                        ArenaManager.this.prepareWorld(ArenaManager.this.plugin.getServer().getWorld("world"));
                        new ChunkLoaderTask(ArenaManager.this.plugin, 750).runTaskTimer((Plugin)ArenaManager.this.plugin, 20, 20);
                    }
                    this.cancel();
                }
            }
        }.runTaskTimer((Plugin)this.plugin, 40, 40);
    }

    public void prepareWorld(World world) {
        world.setPVP(true);
        world.setGameRuleValue("naturalRegeneration", "false");
        world.setGameRuleValue("doDaylightCycle", "false");
        world.setStorm(false);
        world.setDifficulty(Difficulty.NORMAL);
        world.setSpawnLocation(0, 60, 0);
        world.setTime(6000);
        WorldBorder worldBorder = this.plugin.getServer().getWorld("world").getWorldBorder();
        worldBorder.setCenter(0.0, 0.0);
        worldBorder.setSize(1500.0);
        worldBorder.setDamageAmount(1.0);
        worldBorder.setWarningDistance(10);
        worldBorder.setDamageBuffer(1.0);
        worldBorder.setDamageAmount(4.0);
    }

    public void teleport(Player player) {
        int n = this.rand.nextInt(this.lobbySpawns.size());
        GroundUtil.setBuildGround(this.lobbySpawns.get(n));
        player.teleport(this.lobbySpawns.get(n).add(0.0, 10.0, 0.0));
        this.lobbySpawnsUsed.add(this.lobbySpawns.get(n));
        this.lobbySpawns.remove(n);
    }

    public void addSpawnOnQuit(Player player) {
        this.lobbySpawns.add(player.getLocation());
    }

    public void removeSpawns() {
        this.lobbySpawnsUsed.stream().forEach(location -> {
            GroundUtil.removeGround(location);
        }
        );
    }

    public void removeUsedSpawnOnTeleport() {
        this.usedSpawnsToTeleport.stream().forEach(location -> {
            GroundUtil.removeGround(location);
        }
        );
    }

    public void loadSpawn() {
        this.lobbySpawns.clear();
        try {
            for (int i = 1; i <= this.maxPlayers; ++i) {
                this.lobbySpawns.add(Tools.stringToLoc(this.plugin.getConfig().getString("UHCRun.Arena.Spawn." + i)));
            }
        }
        catch (Exception var1_2) {
            // empty catch block
        }
    }

    public void enviarJugadores(Player player) {
        int n = 740;
        int n2 = -740;
        double d = n2 + (int)(Math.random() * (double)(n - n2 + 1));
        double d2 = n2 + (int)(Math.random() * (double)(n - n2 + 1));
        Location location = new Location(this.plugin.getServer().getWorld("world"), d, 120.0, d2);
        if (!location.getChunk().isLoaded()) {
            location.getChunk().load(true);
        }
        this.usedSpawnsToTeleport.add(location);
        GroundUtil.setBuildGround(location);
        player.teleport(location.add(0.0, 10.0, 0.0));
    }

    public void removePVE(Player player) {
        int n = 300;
        int n2 = -300;
        double d = n2 + (int)(Math.random() * (double)(n - n2 + 1));
        double d2 = n2 + (int)(Math.random() * (double)(n - n2 + 1));
        Location location = new Location(this.plugin.getServer().getWorld("world"), d, 120.0, d2);
        if (!location.getChunk().isLoaded()) {
            location.getChunk().load(true);
        }
        player.teleport(location);
    }

    public String getState() {
        switch (GameState.state) {
            case PVE: {
                return "PVE";
            }
            case PVP: {
                return "PVP";
            }
            case DEATHMATCH: {
                return "DEATHMATCH";
            }
            case ENDING: {
                return "END";
            }
        }
        return "Error";
    }

    public double getBordeSize() {
        return this.bordeSize;
    }

    public double getDeathMatchSize() {
        return this.deathMatchSize;
    }

    public int getMaxPlayers() {
        return this.maxPlayers;
    }

    public int getMinPlayers() {
        return this.minPlayers;
    }

    public String getNetherSchematicName() {
        return this.netherSchematicName;
    }

    public List<Location> getLobbySpawns() {
        return this.lobbySpawns;
    }

    public List<Location> getLobbySpawnsUsed() {
        return this.lobbySpawnsUsed;
    }

    public List<Location> getUsedSpawnsToTeleport() {
        return this.usedSpawnsToTeleport;
    }

}

