/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import me.felipefonseca.plugins.manager.NBT_Tag;
import me.felipefonseca.plugins.manager.NBT_Tag_End;

class NBT_Tag_Compound
extends NBT_Tag {
    public Map<String, NBT_Tag> payload;

    public NBT_Tag_Compound(String string) {
        super(10, string);
    }

    public Map<String, NBT_Tag> getPayload() {
        return this.payload;
    }

    public NBT_Tag_Compound(String string, Map<String, NBT_Tag> map) {
        super(8, string);
        this.payload = map;
    }

    public NBT_Tag_Compound(Map<String, NBT_Tag> map) {
        super(8, "");
        this.payload = map;
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        this.payload = new HashMap<String, NBT_Tag>();
        do {
            NBT_Tag nBT_Tag = NBT_Tag.readTag(dataInput);
            if (nBT_Tag.id == 0) break;
            this.payload.put(nBT_Tag.name, nBT_Tag);
        } while (true);
        this.payload.put("__end", new NBT_Tag_End("__end"));
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
        dataOutput.writeUTF(this.name);
        this.writePayload(dataOutput);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
        for (String string : this.payload.keySet()) {
            NBT_Tag nBT_Tag = this.payload.get(string);
            nBT_Tag.writeTag(dataOutput);
        }
    }
}

