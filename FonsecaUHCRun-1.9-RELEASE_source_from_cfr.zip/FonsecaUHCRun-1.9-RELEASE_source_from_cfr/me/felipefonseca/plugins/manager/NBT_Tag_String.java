/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import me.felipefonseca.plugins.manager.NBT_Tag;

class NBT_Tag_String
extends NBT_Tag {
    public String payload;

    public NBT_Tag_String(String string) {
        super(8, string);
    }

    public NBT_Tag_String(String string, String string2) {
        super(8, string);
        this.payload = string2;
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        this.payload = dataInput.readUTF();
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
        dataOutput.writeUTF(this.name);
        this.writePayload(dataOutput);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
        dataOutput.writeUTF(this.payload);
    }

    public String getPayload() {
        return this.payload;
    }
}

