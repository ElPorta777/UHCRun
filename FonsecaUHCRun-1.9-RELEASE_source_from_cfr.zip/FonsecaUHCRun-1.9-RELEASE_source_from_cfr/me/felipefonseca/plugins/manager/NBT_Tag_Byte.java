/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import me.felipefonseca.plugins.manager.NBT_Tag;

class NBT_Tag_Byte
extends NBT_Tag {
    public byte payload;

    public NBT_Tag_Byte(String string) {
        super(1, string);
    }

    public NBT_Tag_Byte(String string, byte by) {
        super(8, string);
        this.payload = by;
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        this.payload = dataInput.readByte();
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
        dataOutput.writeUTF(this.name);
        this.writePayload(dataOutput);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
        dataOutput.write(this.payload);
    }
}

