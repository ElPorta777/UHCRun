/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import me.felipefonseca.plugins.manager.NBT_Tag;

class NBT_Tag_Int
extends NBT_Tag {
    public int payload;

    public NBT_Tag_Int(String string) {
        super(3, string);
    }

    public int getPayload() {
        return this.payload;
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        this.payload = dataInput.readInt();
    }

    public NBT_Tag_Int(String string, int n) {
        super(8, string);
        this.payload = n;
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
        dataOutput.writeUTF(this.name);
        this.writePayload(dataOutput);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
        dataOutput.writeInt(this.payload);
    }
}

