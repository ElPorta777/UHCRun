/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import me.felipefonseca.plugins.manager.NBT_Tag;

class NBT_Tag_Double
extends NBT_Tag {
    public double payload;

    public NBT_Tag_Double(String string) {
        super(6, string);
    }

    public NBT_Tag_Double(String string, double d) {
        super(8, string);
        this.payload = d;
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        this.payload = dataInput.readDouble();
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
        dataOutput.writeUTF(this.name);
        this.writePayload(dataOutput);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
        dataOutput.writeDouble(this.payload);
    }
}

