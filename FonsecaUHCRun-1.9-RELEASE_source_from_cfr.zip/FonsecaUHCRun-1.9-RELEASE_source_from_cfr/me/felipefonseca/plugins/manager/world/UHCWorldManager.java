/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Chunk
 *  org.bukkit.Material
 *  org.bukkit.Server
 *  org.bukkit.World
 *  org.bukkit.World$Environment
 *  org.bukkit.block.Block
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.world.WorldInitEvent
 *  org.bukkit.generator.BlockPopulator
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 */
package me.felipefonseca.plugins.manager.world;

import java.io.InputStream;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.manager.ArenaManager;
import me.felipefonseca.plugins.manager.SchematicLoader;
import me.felipefonseca.plugins.manager.config.ConfigurationManager;
import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.world.WorldInitEvent;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

public class UHCWorldManager
implements Listener {
    private final Main plugin;

    public UHCWorldManager(Main main) {
        this.plugin = main;
    }

    public void init() {
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }

    @EventHandler(ignoreCancelled=1, priority=EventPriority.HIGHEST)
    public void onWorldInit(WorldInitEvent worldInitEvent) {
        if (!this.plugin.getConfigurationManager().isCustomMap()) {
            for (BlockPopulator blockPopulator : worldInitEvent.getWorld().getPopulators()) {
                if (blockPopulator instanceof WorldGenerator) {
                    return;
                }
                if (!(blockPopulator instanceof NetherGenerator)) continue;
                return;
            }
            if (worldInitEvent.getWorld().getEnvironment() == World.Environment.NORMAL) {
                worldInitEvent.getWorld().getPopulators().add(new WorldGenerator());
                worldInitEvent.getWorld().getPopulators().add(new NetherGenerator());
            }
        }
    }

    private void makeOres(Chunk chunk, Random random, int n, int n2, int n3, int n4, Material material) {
        for (int i = 0; i < n4; ++i) {
            Block block;
            int n5 = n + random.nextInt(n4 / 2) - n4 / 4;
            int n6 = n2 + random.nextInt(n4 / 4) - n4 / 8;
            int n7 = n3 + random.nextInt(n4 / 2) - n4 / 4;
            if (n6 > 127 || n6 < 0 || (block = chunk.getBlock(n5 &= 15, n6, n7 &= 15)).getType() != Material.STONE) continue;
            block.setType(material, false);
        }
    }

    private class NetherGenerator
    extends BlockPopulator {
        private NetherGenerator() {
        }

        public void populate(World world, Random random, Chunk chunk) {
            if (chunk.getX() % 20 == 0 && chunk.getZ() % 20 == 0) {
                try {
                    InputStream inputStream = UHCWorldManager.this.plugin.getClass().getClassLoader().getResourceAsStream(UHCWorldManager.this.plugin.getArenaManager().getNetherSchematicName());
                    SchematicLoader schematicLoader = new SchematicLoader();
                    schematicLoader.loadGzipedSchematic(inputStream);
                    int n = schematicLoader.getWidth();
                    short s = schematicLoader.getHeight();
                    int n2 = schematicLoader.getLength();
                    int n3 = 10;
                    int n4 = n3 + s;
                    for (int i = 0; i < n; ++i) {
                        for (int j = 0; j < n2; ++j) {
                            int n5 = i + chunk.getX() * 16;
                            int n6 = j + chunk.getZ() * 16;
                            for (int k = n3; k <= n4 && k < 255; ++k) {
                                int n7 = k - n3;
                                byte by = schematicLoader.getBlockIdAt(i, n7, j);
                                byte by2 = schematicLoader.getMetadataAt(i, n7, j);
                                if (by == -103) {
                                    world.getBlockAt(n5, k, n6).setTypeIdAndData(153, by2, true);
                                }
                                if (by <= -1 || world.getBlockAt(n5, k, n6) == null) continue;
                                world.getBlockAt(n5, k, n6).setTypeIdAndData((int)by, by2, true);
                            }
                        }
                    }
                }
                catch (Exception var4_5) {
                    UHCWorldManager.this.plugin.getLogger().log(Level.SEVERE, "Error with schematic. " + var4_5.getMessage());
                }
            }
        }
    }

    private class WorldGenerator
    extends BlockPopulator {
        private final int[] iterations;
        private final int[] amount;
        private final Material[] type;
        private final int[] maxHeight;

        public WorldGenerator() {
            this.iterations = new int[]{6, 11, 9, 5, 8, 3, 6};
            this.amount = new int[]{15, 15, 10, 14, 10, 12, 10};
            this.type = new Material[]{Material.REDSTONE_ORE, Material.IRON_ORE, Material.LAPIS_ORE, Material.GOLD_ORE, Material.DIAMOND_ORE, Material.OBSIDIAN, Material.COAL_ORE};
            this.maxHeight = new int[]{64, 64, 64, 64, 64, 64, 64};
        }

        public void populate(World world, Random random, Chunk chunk) {
            for (int i = 0; i < this.type.length; ++i) {
                for (int j = 0; j < this.iterations[i]; ++j) {
                    UHCWorldManager.this.makeOres(chunk, random, random.nextInt(16), random.nextInt(this.maxHeight[i]), random.nextInt(16), this.amount[i], this.type[i]);
                }
            }
        }
    }

}

