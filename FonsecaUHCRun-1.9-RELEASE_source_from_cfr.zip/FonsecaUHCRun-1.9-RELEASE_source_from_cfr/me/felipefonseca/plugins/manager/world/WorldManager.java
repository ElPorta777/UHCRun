/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.v1_8_R3.BiomeBase
 *  net.minecraft.server.v1_8_R3.BiomeBase$BiomeMeta
 *  net.minecraft.server.v1_8_R3.BiomeForest
 *  net.minecraft.server.v1_8_R3.EntityChicken
 *  net.minecraft.server.v1_8_R3.EntityCow
 *  net.minecraft.server.v1_8_R3.EntityPig
 *  net.minecraft.server.v1_8_R3.EntityRabbit
 *  net.minecraft.server.v1_8_R3.EntitySheep
 *  net.minecraft.server.v1_8_R3.EntityWolf
 *  org.bukkit.Server
 *  org.bukkit.World
 *  org.bukkit.WorldCreator
 */
package me.felipefonseca.plugins.manager.world;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import me.felipefonseca.plugins.Main;
import net.minecraft.server.v1_8_R3.BiomeBase;
import net.minecraft.server.v1_8_R3.BiomeForest;
import net.minecraft.server.v1_8_R3.EntityChicken;
import net.minecraft.server.v1_8_R3.EntityCow;
import net.minecraft.server.v1_8_R3.EntityPig;
import net.minecraft.server.v1_8_R3.EntityRabbit;
import net.minecraft.server.v1_8_R3.EntitySheep;
import net.minecraft.server.v1_8_R3.EntityWolf;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.WorldCreator;

public class WorldManager {
    private final Main plugin;
    private final String server_dir = new File(".").getAbsolutePath().substring(0, new File(".").getAbsolutePath().length() - 1);

    public WorldManager(Main main) {
        this.plugin = main;
    }

    public void generateBiome() {
        BiomeBase[] arrbiomeBase = BiomeBase.getBiomes();
        BiomeForest biomeForest = new BiomeForest(0, 0);
        BiomeForest biomeForest2 = new BiomeForest(24, 0);
        try {
            Method method = BiomeBase.class.getMethod("b", Integer.TYPE);
            method.setAccessible(true);
            Method method2 = BiomeBase.class.getMethod("a", String.class);
            method2.setAccessible(true);
            Method method3 = BiomeBase.class.getMethod("a", Integer.TYPE);
            method3.setAccessible(true);
            Method method4 = BiomeBase.class.getMethod("a", Float.TYPE, Float.TYPE);
            method4.setAccessible(true);
            Field field = BiomeBase.class.getDeclaredField("au");
            field.setAccessible(true);
            ArrayList<BiomeBase.BiomeMeta> arrayList = new ArrayList<BiomeBase.BiomeMeta>();
            arrayList.add(new BiomeBase.BiomeMeta((Class)EntitySheep.class, 12, 6, 6));
            arrayList.add(new BiomeBase.BiomeMeta((Class)EntityRabbit.class, 10, 3, 3));
            arrayList.add(new BiomeBase.BiomeMeta((Class)EntityPig.class, 12, 6, 6));
            arrayList.add(new BiomeBase.BiomeMeta((Class)EntityChicken.class, 12, 6, 6));
            arrayList.add(new BiomeBase.BiomeMeta((Class)EntityCow.class, 12, 6, 6));
            arrayList.add(new BiomeBase.BiomeMeta((Class)EntityWolf.class, 5, 4, 4));
            field.set((Object)biomeForest, arrayList);
            field.set((Object)biomeForest2, arrayList);
            method.invoke((Object)biomeForest, 353825);
            method2.invoke((Object)biomeForest, "Forest");
            method3.invoke((Object)biomeForest, 5159473);
            method4.invoke((Object)biomeForest, Float.valueOf(0.7f), Float.valueOf(0.8f));
            method.invoke((Object)biomeForest2, 353825);
            method2.invoke((Object)biomeForest2, "Forest");
            method3.invoke((Object)biomeForest2, 5159473);
            method4.invoke((Object)biomeForest2, Float.valueOf(0.7f), Float.valueOf(0.8f));
            Field field2 = BiomeBase.class.getDeclaredField("OCEAN");
            Field field3 = BiomeBase.class.getDeclaredField("DEEP_OCEAN");
            this.setFinalStatic(field2, (Object)biomeForest);
            this.setFinalStatic(field3, (Object)biomeForest2);
            arrbiomeBase[0] = biomeForest;
            arrbiomeBase[24] = biomeForest2;
            Field field4 = BiomeBase.class.getDeclaredField("biomes");
            this.setFinalStatic(field4, arrbiomeBase);
        }
        catch (Exception var4_5) {
            // empty catch block
        }
    }

    public void setFinalStatic(Field field, Object object) {
        field.setAccessible(true);
        Field field2 = Field.class.getDeclaredField("modifiers");
        field2.setAccessible(true);
        field2.setInt(field, field.getModifiers() & -17);
        field.set(null, object);
    }

    public boolean isWorldLoaded(String string) {
        World world = this.plugin.getServer().getWorld(string);
        return world != null;
    }

    public boolean doesWorldExist(String string) {
        if (this.isWorldLoaded(string)) {
            return true;
        }
        File file = new File(this.server_dir + File.separator + string);
        File file2 = new File(this.server_dir + File.separator + string + File.separator + "level.dat");
        return file.exists() && file2.exists();
    }

    public void deleteWorld(String string, boolean bl) {
        try {
            if (!this.doesWorldExist(string)) {
                return;
            }
            if (this.isWorldLoaded(string)) {
                this.unloadWorld(string);
            }
            File file = new File(this.server_dir + File.separator + string);
            this.deleteFolder(file, bl);
        }
        catch (Exception var3_4) {
            // empty catch block
        }
    }

    public boolean unloadWorld(String string) {
        if (!this.doesWorldExist(string)) {
            return false;
        }
        if (!this.isWorldLoaded(string)) {
            return true;
        }
        this.plugin.getServer().unloadWorld(string, true);
        return !this.isWorldLoaded(string);
    }

    public boolean loadWorld(String string) {
        if (!this.doesWorldExist(string)) {
            return false;
        }
        if (this.isWorldLoaded(string)) {
            return true;
        }
        this.plugin.getServer().createWorld(new WorldCreator(string));
        return this.isWorldLoaded(string);
    }

    public void deleteFolder(File file, boolean bl) {
        File[] arrfile = file.listFiles();
        boolean bl2 = true;
        if (arrfile != null) {
            for (File file2 : arrfile) {
                if (file2.isDirectory()) {
                    this.deleteFolder(file2, bl);
                    continue;
                }
                if (!file2.getName().contains("session.lock") || bl) {
                    file2.delete();
                    continue;
                }
                bl2 = false;
            }
        }
        if (bl2) {
            file.delete();
        }
    }
}

