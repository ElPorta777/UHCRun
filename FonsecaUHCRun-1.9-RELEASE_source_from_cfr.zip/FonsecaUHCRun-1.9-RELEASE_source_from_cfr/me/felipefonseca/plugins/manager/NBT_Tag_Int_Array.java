/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import me.felipefonseca.plugins.manager.NBT_Tag;

class NBT_Tag_Int_Array
extends NBT_Tag {
    public int size;
    public int[] payload;

    public NBT_Tag_Int_Array(String string) {
        super(11, string);
    }

    public NBT_Tag_Int_Array(String string, int[] arrn) {
        super(8, string);
        this.payload = arrn;
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        int n;
        this.size = n = dataInput.readInt();
        this.payload = new int[n];
        for (int i = 0; i < n; ++i) {
            this.payload[i] = dataInput.readInt();
        }
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
        dataOutput.writeUTF(this.name);
        dataOutput.writeInt(this.size);
        this.writePayload(dataOutput);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
        for (int n : this.payload) {
            dataOutput.writeInt(n);
        }
    }
}

