/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import me.felipefonseca.plugins.manager.NBT_Tag_Byte;
import me.felipefonseca.plugins.manager.NBT_Tag_Byte_Array;
import me.felipefonseca.plugins.manager.NBT_Tag_Compound;
import me.felipefonseca.plugins.manager.NBT_Tag_Double;
import me.felipefonseca.plugins.manager.NBT_Tag_End;
import me.felipefonseca.plugins.manager.NBT_Tag_Float;
import me.felipefonseca.plugins.manager.NBT_Tag_Int;
import me.felipefonseca.plugins.manager.NBT_Tag_Int_Array;
import me.felipefonseca.plugins.manager.NBT_Tag_List;
import me.felipefonseca.plugins.manager.NBT_Tag_Long;
import me.felipefonseca.plugins.manager.NBT_Tag_Short;
import me.felipefonseca.plugins.manager.NBT_Tag_String;

abstract class NBT_Tag {
    byte id;
    String name;

    public static NBT_Tag getNewTag(int n, String string) {
        switch (n) {
            case 0: {
                return new NBT_Tag_End("");
            }
            case 1: {
                return new NBT_Tag_Byte(string);
            }
            case 2: {
                return new NBT_Tag_Short(string);
            }
            case 3: {
                return new NBT_Tag_Int(string);
            }
            case 4: {
                return new NBT_Tag_Long(string);
            }
            case 5: {
                return new NBT_Tag_Float(string);
            }
            case 6: {
                return new NBT_Tag_Double(string);
            }
            case 7: {
                return new NBT_Tag_Byte_Array(string);
            }
            case 8: {
                return new NBT_Tag_String(string);
            }
            case 9: {
                return new NBT_Tag_List(string);
            }
            case 10: {
                return new NBT_Tag_Compound(string);
            }
            case 11: {
                return new NBT_Tag_Int_Array(string);
            }
        }
        return null;
    }

    public static NBT_Tag readTag(DataInput dataInput) {
        byte by = dataInput.readByte();
        if (by == 0) {
            return new NBT_Tag_End("");
        }
        String string = dataInput.readUTF();
        NBT_Tag nBT_Tag = NBT_Tag.getNewTag(by, string);
        nBT_Tag.readTagPayload(dataInput);
        return nBT_Tag;
    }

    public NBT_Tag(String string) {
        this.id = 0;
        this.name = string;
    }

    protected NBT_Tag(int n, String string) {
        this.id = (byte)n;
        this.name = string;
    }

    public abstract void readTagPayload(DataInput var1);

    public abstract void writeTag(DataOutput var1);

    public abstract void writePayload(DataOutput var1);
}

