/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import me.felipefonseca.plugins.manager.NBT_Tag;

class NBT_Tag_Long
extends NBT_Tag {
    public long payload;

    public NBT_Tag_Long(String string) {
        super(4, string);
    }

    public NBT_Tag_Long(String string, Long l) {
        super(8, string);
        this.payload = l;
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        this.payload = dataInput.readLong();
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
        dataOutput.writeUTF(this.name);
        this.writePayload(dataOutput);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
        dataOutput.writeLong(this.payload);
    }
}

