/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.GameMode
 *  org.bukkit.Server
 *  org.bukkit.World
 *  org.bukkit.WorldBorder
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitScheduler
 *  org.bukkit.scheduler.BukkitTask
 */
package me.felipefonseca.plugins.manager;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.manager.ArenaManager;
import me.felipefonseca.plugins.manager.GameManager;
import me.felipefonseca.plugins.manager.config.ConfigurationManager;
import me.felipefonseca.plugins.utils.Messages;
import me.felipefonseca.plugins.utils.ScoreboardUtil;
import me.felipefonseca.plugins.utils.Tools;
import org.bukkit.GameMode;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;

public class PlayerManager {
    private final Main plugin;
    private final HashMap<Player, Integer> kills;

    public PlayerManager(Main main) {
        this.plugin = main;
        this.kills = new HashMap();
    }

    public void setWaitScoreboard(final Player player) {
        final ScoreboardUtil scoreboardUtil = new ScoreboardUtil(this.plugin.getConfigurationManager().getText("scoreboard_waiting_title"), "lobby");
        new BukkitRunnable(){

            public void run() {
                if (PlayerManager.this.plugin.getGameManager().isInLobby()) {
                    List list = PlayerManager.this.plugin.getConfigurationManager().getLang().getStringList("scoreboard_waiting");
                    int n = list.size();
                    if (list.isEmpty()) {
                        return;
                    }
                    Iterator iterator = list.iterator();
                    while (iterator.hasNext()) {
                        String string = (String)iterator.next();
                        if (string.trim().equals("")) {
                            for (int i = 0; i <= n; ++i) {
                                string = string + " ";
                            }
                        }
                        scoreboardUtil.text(n, string.replace("%players%", new StringBuilder().append("").append(PlayerManager.this.plugin.getGameManager().getPlayersInGame().size()).toString()).replace("%maxplayers%", new StringBuilder().append("").append(PlayerManager.this.plugin.getArenaManager().getMaxPlayers()).toString()).replace("&", "\u00a7") + " ");
                        --n;
                    }
                    scoreboardUtil.build(player);
                } else {
                    scoreboardUtil.reset();
                    this.cancel();
                }
            }
        }.runTaskTimer((Plugin)this.plugin, 20, 20);
    }

    public void setScoreboard(final Player player) {
        final ScoreboardUtil scoreboardUtil = new ScoreboardUtil(this.plugin.getConfigurationManager().getText("scoreboard_ingame_title"), "game");
        new BukkitRunnable(){

            public void run() {
                List list = PlayerManager.this.plugin.getConfigurationManager().getLang().getStringList("scoreboard_ingame");
                int n = list.size();
                if (list.isEmpty()) {
                    return;
                }
                Iterator iterator = list.iterator();
                while (iterator.hasNext()) {
                    String string = (String)iterator.next();
                    if (string.trim().equals("")) {
                        for (int i = 0; i <= n; ++i) {
                            string = string + " ";
                        }
                    }
                    scoreboardUtil.text(n, string.replace("%kills%", new StringBuilder().append("").append(PlayerManager.this.plugin.getPlayerManager().getKillsToString(player)).toString()).replace("%centre%", new StringBuilder().append("").append(Tools.getCentre(player)).toString()).replace("%y%", new StringBuilder().append("").append(Tools.getY(player)).toString()).replace("%players%", new StringBuilder().append("").append(PlayerManager.this.plugin.getGameManager().getPlayersInGame().size()).toString()).replace("%maxplayers%", new StringBuilder().append("").append(PlayerManager.this.plugin.getArenaManager().getMaxPlayers()).toString()).replace("%totalplayers%", new StringBuilder().append("").append(PlayerManager.this.plugin.getServer().getOnlinePlayers().size()).toString()).replace("%state%", PlayerManager.this.plugin.getArenaManager().getState()).replace("%border%", new StringBuilder().append("").append((int)PlayerManager.this.plugin.getServer().getWorld("world").getWorldBorder().getSize() / 2).append("\u00a7d/\u00a7e-").append((int)PlayerManager.this.plugin.getServer().getWorld("world").getWorldBorder().getSize() / 2).toString()).replace("%borderdm%", new StringBuilder().append("").append((int)PlayerManager.this.plugin.getArenaManager().getDeathMatchSize()).toString()).replace("&", "\u00a7") + " ");
                    --n;
                    scoreboardUtil.build(player);
                }
            }
        }.runTaskTimer((Plugin)this.plugin, 1, 1);
    }

    public void setLobbyPlayer(Player player) {
        this.setWaitScoreboard(player);
        this.plugin.getGameManager().addPlayerToGame(player);
        this.setCleanPlayer(player, GameMode.ADVENTURE);
    }

    public void setSpectator(Player player) {
        this.setCleanPlayer(player, GameMode.SPECTATOR);
        this.plugin.getGameManager().getSpectators().add(player);
        this.plugin.getGameManager().getPlayersInGame().stream().forEach(player2 -> {
            player2.hidePlayer(player);
        }
        );
        this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
            this.plugin.getMessageController().sendTitle(player, this.plugin.getConfigurationManager().getText("game.death"), "", 0, 5, 0);
        }
        );
    }

    public void setCleanPlayer(Player player, GameMode gameMode) {
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setExp(0.0f);
        player.setTotalExperience(0);
        player.setLevel(0);
        player.setFireTicks(0);
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.setGameMode(gameMode);
        player.getActivePotionEffects().stream().forEach(potionEffect -> {
            player.removePotionEffect(potionEffect.getType());
        }
        );
    }

    public void sendToServer(Player player) {
        this.plugin.getServer().getScheduler().runTaskAsynchronously((Plugin)this.plugin, () -> {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
            try {
                dataOutputStream.writeUTF("Connect");
                dataOutputStream.writeUTF(this.plugin.getConfig().getString("server"));
            }
            catch (IOException var4_4) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, var4_4);
            }
            player.sendPluginMessage((Plugin)this.plugin, "BungeeCord", byteArrayOutputStream.toByteArray());
        }
        );
    }

    public int getKillsToString(Player player) {
        if (this.kills.containsKey((Object)player)) {
            return this.kills.get((Object)player);
        }
        return 0;
    }

    public void addKillToPlayer(Player player) {
        int n = 0;
        if (this.kills.containsKey((Object)player)) {
            n = this.kills.get((Object)player);
        }
        this.kills.put(player, n + 1);
    }

    public HashMap<Player, Integer> getKills() {
        return this.kills;
    }

}

