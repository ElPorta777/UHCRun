/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import java.util.ArrayList;
import java.util.List;
import me.felipefonseca.plugins.manager.NBT_Tag;

class NBT_Tag_List
extends NBT_Tag {
    public byte tag_type;
    public int size;
    public List<NBT_Tag> payload;

    public NBT_Tag_List(String string) {
        super(9, string);
    }

    public NBT_Tag_List(String string, List<NBT_Tag> list) {
        super(8, string);
        this.payload = list;
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        int n;
        this.tag_type = dataInput.readByte();
        this.size = n = dataInput.readInt();
        this.payload = new ArrayList<NBT_Tag>();
        for (int i = 0; i < n; ++i) {
            NBT_Tag nBT_Tag = NBT_Tag.getNewTag(this.tag_type, "");
            nBT_Tag.readTagPayload(dataInput);
            this.payload.add(nBT_Tag);
        }
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
        dataOutput.writeUTF(this.name);
        dataOutput.writeInt(this.size);
        this.writePayload(dataOutput);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
        for (NBT_Tag nBT_Tag : this.payload) {
            nBT_Tag.writePayload(dataOutput);
        }
    }
}

