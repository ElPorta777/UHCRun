/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Server
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitScheduler
 *  org.bukkit.scheduler.BukkitTask
 */
package me.felipefonseca.plugins.manager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.enums.GameState;
import me.felipefonseca.plugins.manager.ArenaManager;
import me.felipefonseca.plugins.manager.config.ConfigurationManager;
import me.felipefonseca.plugins.task.LobbyTask;
import me.felipefonseca.plugins.task.WinnerTask;
import me.felipefonseca.plugins.utils.Messages;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;

public class GameManager {
    private final Main plugin;
    private final List<Player> playersInGame;
    private final List<Player> playersOffline;
    private final List<Player> spectators;
    private final ReentrantLock _player_ingame_lock;
    private final ReentrantLock _players_offiline_lock;
    private final ReentrantLock _spectators_lock;
    private boolean checkStart = false;

    public GameManager(Main main) {
        this.plugin = main;
        this.playersInGame = new ArrayList<Player>();
        this.playersOffline = new ArrayList<Player>();
        this.spectators = new ArrayList<Player>();
        this._player_ingame_lock = new ReentrantLock(false);
        this._players_offiline_lock = new ReentrantLock(false);
        this._spectators_lock = new ReentrantLock(false);
    }

    public void init() {
        this.playersInGame.clear();
        this.playersOffline.clear();
        this.spectators.clear();
    }

    public void checkWin() {
        if (this.playersInGame.size() < 2) {
            this.playersInGame.stream().forEach(player -> {
                this.plugin.getServer().getOnlinePlayers().stream().forEach(player2 -> {
                    this.plugin.getMessageController().sendTitle(player, this.plugin.getConfigurationManager().getText("game.winner_name").replace("%winner%", player.getDisplayName()), this.plugin.getConfigurationManager().getText("game.winner_sub"), 10, 15, 10);
                    GameState.state = GameState.ENDING;
                    new WinnerTask(this.plugin).runTaskTimer((Plugin)this.plugin, 20, 20);
                }
                );
            }
            );
        }
    }

    public void forceStart() {
        if (!this.checkStart) {
            this.checkStart = true;
            new LobbyTask(this.plugin).runTaskTimer((Plugin)this.plugin, 20, 20);
        }
    }

    public void checkStart() {
        if (!this.checkStart && this.playersInGame.size() == this.plugin.getArenaManager().getMinPlayers()) {
            this.checkStart = true;
            new LobbyTask(this.plugin).runTaskTimer((Plugin)this.plugin, 20, 20);
        }
    }

    public void close() {
        if (!this.plugin.getGameManager().isInLobby() && (this.plugin.getServer().getOnlinePlayers().size() == 1 || this.plugin.getServer().getOnlinePlayers().isEmpty())) {
            this.plugin.getServer().shutdown();
        }
    }

    public void removeOfflinePlayers() {
        this.playersOffline.clear();
        this.playersInGame.stream().map(player -> {
            this.plugin.getMessageController().sendActionBar(player, this.plugin.getConfigurationManager().getText("game.players_removed_list"));
            return player;
        }
        ).forEach(player -> {
            player.playSound(player.getLocation(), Sound.IRONGOLEM_DEATH, 1.0f, 1.0f);
        }
        );
        this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
            this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("game.players_removed"));
        }
        );
    }

    public void addPlayerToGame(Player player) {
        this._player_ingame_lock.lock();
        try {
            this.playersInGame.remove((Object)player);
            this.playersInGame.add(player);
        }
        finally {
            this._player_ingame_lock.unlock();
        }
    }

    public void addOfflinePlayer(Player player) {
        this._players_offiline_lock.lock();
        try {
            this.playersOffline.remove((Object)player);
            this.playersOffline.add(player);
        }
        finally {
            this._players_offiline_lock.unlock();
        }
    }

    public void addSpectator(Player player) {
        this._spectators_lock.lock();
        try {
            this.spectators.remove((Object)player);
            this.spectators.add(player);
        }
        finally {
            this._spectators_lock.unlock();
        }
    }

    public void removePlayerFromGame(Player player) {
        this.playersInGame.remove((Object)player);
    }

    public void removeOfflinePlayer(Player player) {
        this.playersOffline.remove((Object)player);
    }

    public void removeSpectator(Player player) {
        this.spectators.remove((Object)player);
    }

    public boolean isEnding() {
        return GameState.state == GameState.ENDING;
    }

    public boolean isInDeathMatch() {
        return GameState.state == GameState.DEATHMATCH;
    }

    public boolean isInPVP() {
        return GameState.state == GameState.PVP;
    }

    public boolean isInPVE() {
        return GameState.state == GameState.PVE;
    }

    public boolean isTeleporting() {
        return GameState.state == GameState.TELEPORTING;
    }

    public boolean isInLobby() {
        return GameState.state == GameState.LOBBY;
    }

    public List<Player> getPlayersInGame() {
        return this.playersInGame;
    }

    public List<Player> getPlayersOffline() {
        return this.playersOffline;
    }

    public List<Player> getSpectators() {
        return this.spectators;
    }
}

