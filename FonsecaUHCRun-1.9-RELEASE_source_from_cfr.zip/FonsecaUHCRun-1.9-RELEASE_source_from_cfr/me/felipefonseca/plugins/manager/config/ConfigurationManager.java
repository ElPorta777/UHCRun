/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatColor
 *  org.bukkit.configuration.InvalidConfigurationException
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 */
package me.felipefonseca.plugins.manager.config;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;
import me.felipefonseca.plugins.Main;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class ConfigurationManager {
    private final Main plugin;
    private final YamlConfiguration lang;
    private boolean customMap;

    public ConfigurationManager(Main main) {
        this.plugin = main;
        this.lang = new YamlConfiguration();
    }

    public void load() {
        if (!new File(this.plugin.getDataFolder(), "config.yml").exists()) {
            this.plugin.saveDefaultConfig();
        }
        this.customMap = this.plugin.getConfig().getBoolean("customMap");
        File file = new File(this.plugin.getDataFolder(), "lang.yml");
        File file2 = new File(this.plugin.getDataFolder(), "lang.yml");
        if (!file2.exists()) {
            this.plugin.saveResource(file2.getName(), false);
        }
        if (file.exists()) {
            try {
                this.lang.load(file);
            }
            catch (IOException | InvalidConfigurationException var3_3) {
                this.plugin.getLogger().severe(var3_3.toString());
            }
        }
    }

    public String getText(String string) {
        String string2 = this.lang.getString(string);
        string2 = string2 == null ? string : ChatColor.translateAlternateColorCodes((char)'&', (String)string2);
        return string2;
    }

    public YamlConfiguration getLang() {
        return this.lang;
    }

    public boolean isCustomMap() {
        return this.customMap;
    }
}

