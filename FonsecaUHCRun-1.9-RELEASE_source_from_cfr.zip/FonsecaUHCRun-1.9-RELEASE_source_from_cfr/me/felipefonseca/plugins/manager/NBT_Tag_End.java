/*
 * Decompiled with CFR 0_115.
 */
package me.felipefonseca.plugins.manager;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.PrintStream;
import me.felipefonseca.plugins.manager.NBT_Tag;

class NBT_Tag_End
extends NBT_Tag {
    public NBT_Tag_End(String string) {
        super(0, "");
    }

    public NBT_Tag_End(String string, int n) {
        super(8, string);
    }

    @Override
    public void readTagPayload(DataInput dataInput) {
        System.out.println("An error has occoured. An named binary tree tag 'end' has had it's payload read. It doesn't have a payload. Fix your code :D");
    }

    @Override
    public void writeTag(DataOutput dataOutput) {
        dataOutput.write(this.id);
    }

    @Override
    public void writePayload(DataOutput dataOutput) {
    }
}

