/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Server
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.event.world.ChunkUnloadEvent
 *  org.bukkit.event.world.PortalCreateEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 */
package me.felipefonseca.plugins.listener;

import me.felipefonseca.plugins.Main;
import org.bukkit.Server;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.event.world.PortalCreateEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

public class WorldListener
implements Listener {
    private final Main plugin;

    public WorldListener(Main main) {
        this.plugin = main;
    }

    public void init() {
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }

    @EventHandler(ignoreCancelled=1, priority=EventPriority.HIGHEST)
    public void onLoadChunk(ChunkUnloadEvent chunkUnloadEvent) {
        chunkUnloadEvent.setCancelled(false);
    }

    @EventHandler
    public void onPortalCreate(PortalCreateEvent portalCreateEvent) {
        portalCreateEvent.setCancelled(true);
    }

    public void unregisterAllWorldEvents() {
        HandlerList.unregisterAll((Listener)this);
    }
}

