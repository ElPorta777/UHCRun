/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Server
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Arrow
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LightningStrike
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityDamageByBlockEvent
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.event.player.PlayerDropItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerItemConsumeEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerLoginEvent
 *  org.bukkit.event.player.PlayerLoginEvent$Result
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerPickupItemEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.bukkit.projectiles.ProjectileSource
 *  org.bukkit.scheduler.BukkitScheduler
 *  org.bukkit.scheduler.BukkitTask
 */
package me.felipefonseca.plugins.listener;

import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;
import me.felipefonseca.plugins.Main;
import me.felipefonseca.plugins.enums.GameState;
import me.felipefonseca.plugins.enums.MoveState;
import me.felipefonseca.plugins.manager.ArenaManager;
import me.felipefonseca.plugins.manager.GameManager;
import me.felipefonseca.plugins.manager.PlayerManager;
import me.felipefonseca.plugins.manager.config.ConfigurationManager;
import me.felipefonseca.plugins.utils.Messages;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LightningStrike;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;

public class PlayerListener
implements Listener {
    private final Main plugin;

    public PlayerListener(Main main) {
        this.plugin = main;
    }

    public void init() {
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }

    @EventHandler
    public void onPlayerLogin(PlayerLoginEvent playerLoginEvent) {
        Player player = playerLoginEvent.getPlayer();
        if (GameState.state == GameState.PREPARING) {
            playerLoginEvent.disallow(PlayerLoginEvent.Result.KICK_OTHER, "Preparing world...");
            playerLoginEvent.setKickMessage("The world is generating.");
        } else if (this.plugin.getGameManager().isInLobby() && this.plugin.getGameManager().getPlayersInGame().size() <= this.plugin.getArenaManager().getMaxPlayers()) {
            playerLoginEvent.allow();
            this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                this.plugin.getArenaManager().teleport(player);
            }
            );
        } else if (this.plugin.getGameManager().isInPVE() && this.plugin.getGameManager().getPlayersOffline().contains((Object)player)) {
            playerLoginEvent.allow();
        } else if (this.plugin.getGameManager().isTeleporting() || this.plugin.getGameManager().isInDeathMatch() || this.plugin.getGameManager().isInPVP() || this.plugin.getGameManager().isEnding()) {
            if (player.hasPermission("UHCRun.Pass")) {
                playerLoginEvent.allow();
            } else {
                playerLoginEvent.setKickMessage(this.plugin.getConfigurationManager().getText("game.need_pass"));
            }
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent playerJoinEvent) {
        Player player = playerJoinEvent.getPlayer();
        playerJoinEvent.setJoinMessage(null);
        if (this.plugin.getGameManager().isInLobby()) {
            this.plugin.getPlayerManager().setLobbyPlayer(player);
            this.plugin.getGameManager().checkStart();
            this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("game.player_join_broadcast").replace("%player%", player.getDisplayName()).replace("%currentplayers%", "" + this.plugin.getGameManager().getPlayersInGame().size() + "").replace("%maxplayers%", "" + this.plugin.getArenaManager().getMaxPlayers()));
            }
            );
        } else if (this.plugin.getGameManager().isInPVE() && this.plugin.getGameManager().getPlayersOffline().contains((Object)player)) {
            this.plugin.getGameManager().removeOfflinePlayer(player);
            this.plugin.getGameManager().addPlayerToGame(player);
            this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                this.plugin.getMessageController().sendMessage(player, this.plugin.getConfigurationManager().getText("game.player_back"));
            }
            );
        } else {
            this.plugin.getPlayerManager().setSpectator(player);
        }
        this.plugin.getGameManager().close();
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent playerQuitEvent) {
        Player player = playerQuitEvent.getPlayer();
        playerQuitEvent.setQuitMessage(null);
        if (this.plugin.getGameManager().isInLobby()) {
            this.plugin.getGameManager().removePlayerFromGame(player);
            this.plugin.getArenaManager().addSpawnOnQuit(player);
            this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("game.player_quit_broadcast").replace("%player%", player.getDisplayName()).replace("%currentplayers%", "" + this.plugin.getGameManager().getPlayersInGame().size() + "").replace("%maxplayers%", "" + this.plugin.getArenaManager().getMaxPlayers()));
            }
            );
        } else if (this.plugin.getGameManager().isInPVE()) {
            if (this.plugin.getGameManager().getPlayersInGame().contains((Object)player)) {
                this.plugin.getGameManager().removePlayerFromGame(player);
                this.plugin.getGameManager().checkWin();
                this.plugin.getGameManager().addOfflinePlayer(player);
                this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                    this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("game.player_quit_in_pve_broadcast").replace("%player%", player.getDisplayName()).replace("%currentplayers%", "" + this.plugin.getGameManager().getPlayersInGame().size() + "").replace("%maxplayers%", "" + this.plugin.getArenaManager().getMaxPlayers()));
                }
                );
            }
        } else if (this.plugin.getGameManager().isInDeathMatch() || this.plugin.getGameManager().isInPVP()) {
            this.plugin.getGameManager().removePlayerFromGame(player);
            this.plugin.getGameManager().removeSpectator(player);
            this.plugin.getGameManager().checkWin();
        } else if (this.plugin.getGameManager().isEnding()) {
            this.plugin.getGameManager().removePlayerFromGame(player);
            this.plugin.getGameManager().removeSpectator(player);
        }
        this.plugin.getGameManager().close();
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent playerDeathEvent) {
        playerDeathEvent.setDeathMessage(null);
        if (this.plugin.getGameManager().getPlayersInGame().contains((Object)playerDeathEvent.getEntity())) {
            if (this.plugin.getGameManager().isInPVP() || this.plugin.getGameManager().isInPVE()) {
                if (playerDeathEvent.getEntity().getKiller() instanceof Player) {
                    this.plugin.getGameManager().removePlayerFromGame(playerDeathEvent.getEntity());
                    playerDeathEvent.getEntity().getWorld().strikeLightningEffect(playerDeathEvent.getEntity().getLocation());
                    this.plugin.getPlayerManager().setSpectator(playerDeathEvent.getEntity());
                    this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                        this.sendDeathSound("NORMAL");
                        this.plugin.getPlayerManager().addKillToPlayer(playerDeathEvent.getEntity().getKiller());
                        this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("game.player_death_by_player_broadcast").replace("%death%", playerDeathEvent.getEntity().getDisplayName()).replace("%killer%", playerDeathEvent.getEntity().getKiller().getDisplayName()));
                    }
                    );
                } else {
                    this.plugin.getGameManager().removePlayerFromGame(playerDeathEvent.getEntity());
                    this.plugin.getPlayerManager().setSpectator(playerDeathEvent.getEntity());
                    playerDeathEvent.getEntity().getWorld().strikeLightningEffect(playerDeathEvent.getEntity().getLocation());
                    this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                        this.sendDeathSound("NORMAL");
                        this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("game.player_death_broadcast").replace("%death%", playerDeathEvent.getEntity().getDisplayName()));
                    }
                    );
                }
                this.plugin.getGameManager().checkWin();
            } else if (this.plugin.getGameManager().isInDeathMatch()) {
                if (playerDeathEvent.getEntity().getKiller() instanceof Player) {
                    this.plugin.getGameManager().removePlayerFromGame(playerDeathEvent.getEntity());
                    this.plugin.getPlayerManager().setSpectator(playerDeathEvent.getEntity());
                    playerDeathEvent.getEntity().getWorld().strikeLightningEffect(playerDeathEvent.getEntity().getLocation());
                    this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                        this.sendDeathSound("DM");
                        this.plugin.getPlayerManager().addKillToPlayer(playerDeathEvent.getEntity().getKiller());
                        this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("game.player_death_by_player_broadcast").replace("%death%", playerDeathEvent.getEntity().getDisplayName()).replace("%killer%", playerDeathEvent.getEntity().getKiller().getDisplayName()));
                    }
                    );
                } else {
                    this.plugin.getGameManager().removePlayerFromGame(playerDeathEvent.getEntity());
                    this.plugin.getPlayerManager().setSpectator(playerDeathEvent.getEntity());
                    playerDeathEvent.getEntity().getWorld().strikeLightningEffect(playerDeathEvent.getEntity().getLocation());
                    this.plugin.getServer().getScheduler().runTask((Plugin)this.plugin, () -> {
                        this.sendDeathSound("DM");
                        this.plugin.getMessageController().sendBroadcast(this.plugin.getConfigurationManager().getText("game.player_death_broadcast").replace("%death%", playerDeathEvent.getEntity().getDisplayName()));
                    }
                    );
                }
                this.plugin.getGameManager().checkWin();
            }
        }
        this.plugin.getGameManager().close();
    }

    @EventHandler
    public void onPlayerEat(PlayerItemConsumeEvent playerItemConsumeEvent) {
        if (playerItemConsumeEvent.getItem().getType().equals((Object)Material.GOLDEN_APPLE)) {
            playerItemConsumeEvent.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 1), true);
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent playerInteractEvent) {
        if (this.plugin.getGameManager().isInLobby()) {
            // empty if block
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onBreakObsidian(PlayerInteractEvent playerInteractEvent) {
        Block block = playerInteractEvent.getClickedBlock();
        if (block != null && block.getType() != Material.OBSIDIAN) {
            playerInteractEvent.getPlayer().removePotionEffect(PotionEffectType.FAST_DIGGING);
        } else if (block != null && block.getType() == Material.OBSIDIAN) {
            playerInteractEvent.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, 400, 2));
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent entityDamageEvent) {
        if (this.plugin.getGameManager().isInLobby() || this.plugin.getGameManager().isTeleporting() || this.plugin.getGameManager().isEnding()) {
            entityDamageEvent.setCancelled(true);
        } else {
            entityDamageEvent.setCancelled(false);
        }
    }

    @EventHandler
    public void onEntityDamageByBlock(EntityDamageByBlockEvent entityDamageByBlockEvent) {
        if (this.plugin.getGameManager().isInLobby() || this.plugin.getGameManager().isTeleporting() || this.plugin.getGameManager().isEnding()) {
            entityDamageByBlockEvent.setCancelled(true);
        } else if (this.plugin.getGameManager().isInPVE()) {
            entityDamageByBlockEvent.setCancelled(false);
        } else if (this.plugin.getGameManager().isInPVP() || this.plugin.getGameManager().isInDeathMatch()) {
            entityDamageByBlockEvent.setCancelled(false);
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent entityDamageByEntityEvent) {
        if (this.plugin.getGameManager().isInLobby() || this.plugin.getGameManager().isInPVE() || this.plugin.getGameManager().isEnding()) {
            if (entityDamageByEntityEvent.getEntity() instanceof Player) {
                Arrow arrow;
                if (entityDamageByEntityEvent.getDamager() instanceof Player) {
                    entityDamageByEntityEvent.setCancelled(true);
                }
                if (entityDamageByEntityEvent.getDamager() instanceof Arrow && (arrow = (Arrow)entityDamageByEntityEvent.getDamager()).getShooter() instanceof Player) {
                    arrow.remove();
                    entityDamageByEntityEvent.setCancelled(true);
                }
            } else {
                entityDamageByEntityEvent.setCancelled(false);
            }
        } else {
            entityDamageByEntityEvent.setCancelled(false);
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent playerMoveEvent) {
        if ((this.plugin.getGameManager().isTeleporting() || this.plugin.getGameManager().isInLobby()) && (playerMoveEvent.getFrom().getBlockZ() != playerMoveEvent.getTo().getBlockZ() || playerMoveEvent.getFrom().getBlockX() != playerMoveEvent.getTo().getBlockX())) {
            playerMoveEvent.setTo(playerMoveEvent.getFrom());
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void onSpecialMove(PlayerMoveEvent playerMoveEvent) {
        if (MoveState.state == MoveState.NOTEMOVAIMIERGDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA && (playerMoveEvent.getFrom().getBlockZ() != playerMoveEvent.getTo().getBlockZ() || playerMoveEvent.getFrom().getBlockY() != playerMoveEvent.getTo().getBlockY() || playerMoveEvent.getFrom().getBlockX() != playerMoveEvent.getTo().getBlockX())) {
            playerMoveEvent.setTo(playerMoveEvent.getFrom());
        }
    }

    @EventHandler
    public void onPlayerDrop(PlayerDropItemEvent playerDropItemEvent) {
        if (this.plugin.getGameManager().isInLobby() || this.plugin.getGameManager().isTeleporting() || this.plugin.getGameManager().isEnding()) {
            playerDropItemEvent.setCancelled(true);
        } else {
            playerDropItemEvent.setCancelled(false);
        }
    }

    @EventHandler
    public void onPlayerFood(FoodLevelChangeEvent foodLevelChangeEvent) {
        if (this.plugin.getGameManager().isInLobby() || this.plugin.getGameManager().isTeleporting() || this.plugin.getGameManager().isEnding()) {
            foodLevelChangeEvent.setCancelled(true);
        } else {
            foodLevelChangeEvent.setCancelled(false);
        }
    }

    @EventHandler
    public void onPlayerPickUp(PlayerPickupItemEvent playerPickupItemEvent) {
        if (this.plugin.getGameManager().isInLobby() || this.plugin.getGameManager().isTeleporting() || this.plugin.getGameManager().isEnding()) {
            playerPickupItemEvent.setCancelled(true);
        } else {
            playerPickupItemEvent.setCancelled(false);
        }
    }

    private void sendDeathSound(String string) {
        switch (string) {
            default: {
                this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
                    player.playSound(player.getLocation(), Sound.WITHER_DEATH, 1.0f, 1.0f);
                }
                );
                break;
            }
            case "DM": {
                this.plugin.getGameManager().getPlayersInGame().stream().forEach(player -> {
                    player.playSound(player.getLocation(), Sound.WITHER_SPAWN, 1.0f, 1.0f);
                }
                );
            }
        }
    }
}

