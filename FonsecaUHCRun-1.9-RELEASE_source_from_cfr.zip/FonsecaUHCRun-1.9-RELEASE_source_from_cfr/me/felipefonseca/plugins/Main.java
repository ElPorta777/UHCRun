/*
 * Decompiled with CFR 0_115.
 * 
 * Could not load the following classes:
 *  org.bukkit.Server
 *  org.bukkit.configuration.InvalidConfigurationException
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.plugin.messaging.Messenger
 */
package me.felipefonseca.plugins;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Level;
import java.util.logging.Logger;
import me.felipefonseca.plugins.CommandManager;
import me.felipefonseca.plugins.enums.GameState;
import me.felipefonseca.plugins.listener.GameListener;
import me.felipefonseca.plugins.listener.PlayerListener;
import me.felipefonseca.plugins.listener.WorldListener;
import me.felipefonseca.plugins.manager.ArenaManager;
import me.felipefonseca.plugins.manager.GameManager;
import me.felipefonseca.plugins.manager.PlayerManager;
import me.felipefonseca.plugins.manager.config.ConfigurationManager;
import me.felipefonseca.plugins.manager.world.UHCWorldManager;
import me.felipefonseca.plugins.manager.world.WorldManager;
import me.felipefonseca.plugins.utils.Messages;
import org.bukkit.Server;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.Messenger;

public class Main
extends JavaPlugin {
    private final GameListener gl;
    private final PlayerListener pl;
    private final WorldListener wl;
    private final ConfigurationManager cgm;
    private final WorldManager wm;
    private final ArenaManager am;
    private final GameManager gm;
    private final PlayerManager pm;
    private final UHCWorldManager uwm;
    private final Messages msg;
    private final CommandManager cm;

    public Main() {
        this.gl = new GameListener(this);
        this.pl = new PlayerListener(this);
        this.wl = new WorldListener(this);
        this.cgm = new ConfigurationManager(this);
        this.wm = new WorldManager(this);
        this.am = new ArenaManager(this);
        this.gm = new GameManager(this);
        this.pm = new PlayerManager(this);
        this.uwm = new UHCWorldManager(this);
        this.msg = new Messages(this);
        this.cm = new CommandManager(this);
    }

    public void onEnable() {
        Main.loadConfig0();
        GameState.state = GameState.PREPARING;
        try {
            this.cgm.load();
        }
        catch (IOException | InvalidConfigurationException var1_1) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, (Throwable)var1_1);
        }
        this.msg.init();
        this.am.loadInfo();
        this.am.prepareArenaManager();
        this.uwm.init();
        this.wl.init();
        this.pl.init();
        this.gl.init();
        this.cm.init();
        this.getServer().setSpawnRadius(0);
        this.getServer().getMessenger().registerOutgoingPluginChannel((Plugin)this, "BungeeCord");
        this.getLogger().log(Level.INFO, "UHCRun: Enabled");
    }

    public void onDisable() {
        this.saveConfig();
        this.getLogger().log(Level.INFO, "UHCRun: Disabled");
    }

    public ConfigurationManager getConfigurationManager() {
        return this.cgm;
    }

    public WorldManager getWorldManager() {
        return this.wm;
    }

    public ArenaManager getArenaManager() {
        return this.am;
    }

    public GameManager getGameManager() {
        return this.gm;
    }

    public PlayerManager getPlayerManager() {
        return this.pm;
    }

    public Messages getMessageController() {
        return this.msg;
    }
}

